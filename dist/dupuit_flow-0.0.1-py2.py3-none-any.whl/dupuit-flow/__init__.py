# -*- coding: utf-8 -*-
"""
Purpose
=======

YOUR_PACKAGE: a Python template.

Subpackages
===========

.. autosummary::
    core

"""
from __future__ import absolute_import

from YOUR_PACKAGE._version import __version__
from YOUR_PACKAGE import core

__all__ = ["__version__"]
__all__ += ["core"]