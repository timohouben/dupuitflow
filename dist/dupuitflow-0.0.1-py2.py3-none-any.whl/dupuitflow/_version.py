# -*- coding: utf-8 -*-
"""Provide a central version."""
__version__ = "0.0.0.dev2"
