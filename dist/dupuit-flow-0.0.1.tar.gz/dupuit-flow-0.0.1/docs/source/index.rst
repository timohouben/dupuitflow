=======================
YOUR_PACKAGE Quickstart
=======================

YOUR_PACKAGE: A Python template.


Installation
============

.. code-block:: none

    pip install YOUR_PACKAGE


Further Information
===================

Requirements
============

License
=======

`MIT <https://github.com/YOUR_NAME/YOUR_PACKAGE/blob/master/LICENSE>`_ © 2019
