YOUR_PACKAGE.core
=================

.. automodule:: YOUR_PACKAGE.core
   :members:
   :undoc-members:
   :inherited-members:
   :show-inheritance:

.. raw:: latex

    \clearpage
