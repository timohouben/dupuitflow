================
YOUR_PACKAGE API
================

.. automodule:: YOUR_PACKAGE

.. raw:: latex

    \clearpage

.. toctree::
   :hidden:

   core.rst
