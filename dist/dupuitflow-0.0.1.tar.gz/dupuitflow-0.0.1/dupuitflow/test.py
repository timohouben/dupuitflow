# -*- coding: utf-8 -*-
"""
Test file.
"""

def you_know_what():
    eingabe = input("You know what?")
    print("I love and miss you! :-*")
    print("\n       .....           .....            \n   ,ad8PPPP88b,     ,d88PPPP8ba,        \n  d8P'      'Y8b, ,d8P'      'Y8b       \n dP'           '8a8'           `Yd      \n 8(              ''              )8      \n I8                             8I      \n  Yb,                         ,dP       \n   .8a,                     ,a8.        \n     .8a,                 ,a8.      \n       .Yba             adP.        \n         `Y8a         a8P'      \n           `88,     ,88'        \n             '8b   d8'      \n              '8b d8'       \n               `888'        \n                 .      \n")
