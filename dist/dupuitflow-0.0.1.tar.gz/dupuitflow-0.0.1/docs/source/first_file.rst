dupuitflow.first_file
=====================

.. automodule:: dupuitflow.first_file
   :members:
   :undoc-members:
   :inherited-members:
   :show-inheritance:

.. raw:: latex

    \clearpage
