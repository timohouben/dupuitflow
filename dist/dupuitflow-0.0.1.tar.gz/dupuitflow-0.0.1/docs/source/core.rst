dupuitflow.core
=================

.. automodule:: dupuitflow.core
   :members:
   :undoc-members:
   :inherited-members:
   :show-inheritance:

.. raw:: latex

    \clearpage
