================
dupuitflow API
================

.. automodule:: dupuitflow

.. raw:: latex

    \clearpage

.. toctree::
   :hidden:

   core.rst
   first_file.rst
