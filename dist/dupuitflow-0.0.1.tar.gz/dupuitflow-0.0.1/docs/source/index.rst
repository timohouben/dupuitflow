=======================
dupuitflow Quickstart
=======================

dupuitflow: A Python template.


Installation
============

.. code-block:: none

    pip install dupuitflow


Further Information
===================

Requirements
============

License
=======

`MIT <https://github.com/YOUR_NAME/dupuitflow/blob/master/LICENSE>`_ © 2019
